require('./lib/modern-module-resolution');
