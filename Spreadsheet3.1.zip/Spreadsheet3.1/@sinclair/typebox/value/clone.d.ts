export declare namespace ValueClone {
    function Clone<T extends unknown>(value: T): T;
}
