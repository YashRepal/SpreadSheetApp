'use strict';
require('../register')('es6-promise', {Promise: require('es6-promise').Promise})
