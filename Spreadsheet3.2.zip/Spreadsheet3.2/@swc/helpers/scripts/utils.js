export function root(...p) {
    return path.resolve(__dirname, "..", ...p);
}
