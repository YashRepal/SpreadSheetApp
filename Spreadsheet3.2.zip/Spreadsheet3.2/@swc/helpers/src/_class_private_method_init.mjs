export { _ as default } from "../esm/_class_private_method_init.js";
