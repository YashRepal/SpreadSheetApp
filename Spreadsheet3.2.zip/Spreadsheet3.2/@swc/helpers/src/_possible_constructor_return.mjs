export { _ as default } from "../esm/_possible_constructor_return.js";
