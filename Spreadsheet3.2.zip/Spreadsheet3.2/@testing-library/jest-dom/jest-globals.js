const globals = require('@jest/globals')
const extensions = require('./dist/matchers')

globals.expect.extend(extensions)
