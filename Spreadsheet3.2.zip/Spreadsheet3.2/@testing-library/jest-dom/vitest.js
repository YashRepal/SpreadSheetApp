import {expect} from 'vitest'
import * as extensions from './dist/matchers'

expect.extend(extensions)
