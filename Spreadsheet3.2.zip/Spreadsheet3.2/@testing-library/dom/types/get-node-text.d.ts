export function getNodeText(node: HTMLElement): string
