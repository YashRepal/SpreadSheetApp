# Installation
> `npm install --save @types/yargs-parser`

# Summary
This package contains type definitions for yargs-parser (https://github.com/yargs/yargs-parser#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/yargs-parser.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 21:36:25 GMT
 * Dependencies: none

# Credits
These definitions were written by [Miles Johnson](https://github.com/milesj).
