// pages/_app.js or pages/_document.js
import { Inter } from '@next/font/google'

const inter = Inter({ subsets: ['latin'] });
