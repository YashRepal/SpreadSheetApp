// __tests__/Spreadsheet.test.js
import { render, screen, fireEvent } from '@testing-library/react';
import Spreadsheet from '../components/Spreadsheet';

test('renders spreadsheet and interacts with cells', () => {
  render(<Spreadsheet />);
  const cell = screen.getByRole('textbox');
  fireEvent.change(cell, { target: { value: 'Test' } });
  expect(cell.value).toBe('Test');
});
