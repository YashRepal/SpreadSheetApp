// pages/index.js
import Head from 'next/head'
import Spreadsheet from '../components/Spreadsheet'

export default function Home() {
  return (
    <div>
      <Head>
        <title>GoKapture Spreadsheet</title>
        <meta name="description" content="A spreadsheet app built with Next.js and Tailwind CSS" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <main className="min-h-screen bg-gray-100">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold mb-6">GoKapture Spreadsheet</h1>
          <Spreadsheet />
        </div>
      </main>
    </div>
  )
}
