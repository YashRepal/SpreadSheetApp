// store/useStore.js
import create from 'zustand'

const useStore = create((set) => ({
  cells: Array(1000).fill('').map(() => ({ content: '', format: { textAlign: 'left', fontSize: '14px' } })),
  updateCell: (index, content) => set((state) => {
    const cells = [...state.cells];
    cells[index].content = content;
    return { cells };
  }),
  updateCellFormat: (index, format) => set((state) => {
    const cells = [...state.cells];
    cells[index].format = { ...cells[index].format, ...format };
    return { cells };
  }),
  search: (query) => set((state) => ({
    searchResults: state.cells.filter(cell => cell.content.includes(query))
  })),
}));
export default useStore;
