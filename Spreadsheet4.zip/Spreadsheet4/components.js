// components/Spreadsheet.js
import React, { useState } from 'react';
import useStore from '../store/useStore';

const Spreadsheet = () => {
  const { cells, updateCell, updateCellFormat, search } = useStore();
  const [searchQuery, setSearchQuery] = useState('');

  const handleCellChange = (index, e) => {
    updateCell(index, e.target.value);
  };

  const handleFormatChange = (index, formatType, value) => {
    updateCellFormat(index, { [formatType]: value });
  };

  const filteredCells = cells; // Add pagination or filtering logic as needed

  return (
    <div className="p-4">
      <input
        type="text"
        placeholder="Search..."
        value={searchQuery}
        onChange={(e) => {
          setSearchQuery(e.target.value);
          search(e.target.value);
        }}
        className="mb-4 p-2 border rounded"
      />
      <div className="grid grid-cols-10 gap-1">
        {filteredCells.map((cell, index) => (
          <div key={index} className="relative">
            <textarea
              value={cell.content}
              onChange={(e) => handleCellChange(index, e)}
              style={{
                textAlign: cell.format.textAlign,
                fontSize: cell.format.fontSize,
              }}
              className="w-full h-24 p-2 border border-gray-300 rounded"
            />
            {/* Add formatting controls */}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Spreadsheet;
